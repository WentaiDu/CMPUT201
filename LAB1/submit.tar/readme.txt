1.Show the contents of your is_com.txt
	cat ls_com.txt
2.generate the ls_out.txt file
	cat ls_com.txt > ls_out.txt
3.compole hello.c into an executable called hello
	this code is missing a curly brace'}' and two semicolons ';'.
	Every function should end with a curly brace. And every complete line of code should also
	end with a semicolon. The C program is based on the semiolon to break sentences.
 
	gcc -Wall -std=c99 hello.c -o hello
4.run hello
	./hello
5.create a .tar file containing ls_com.txt,Ls_out.txt,hello.c and this file readme.txt
	tar -cvf submit.tar ls_com.txt ls_out.txt readme.txt hello.c
6.create a temporary temp/directory
	mkdir temp
7.copy the .tar file to temp/ directory
	cp submit.tar /temp
8.untar file
	tar -xvf submit.tar

reference :https://www.fprintf.net/imCheatSheet.html
