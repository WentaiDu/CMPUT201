#include <stdio.h>
/*new function */
int main(){
	/*display the word*/
	printf("Hello world!\n");
	return 0 ;
	}
