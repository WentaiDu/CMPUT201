author: Wentai Du

dicuss with: Bowen Xiao

Books: 
Our Textbook
c programming language from entry to master 4th

Link:
https://www.youtube.com/watch?v=BpReg7ZT2MU&feature=youtu.be
https://zhuanlan.zhihu.com/p/93753907
https://www.google.com/search?q=%25c&oq=%25c&aqs=chrome..69i57j69i59l3j69i65l2.623j0j9&sourceid=chrome&ie=UTF-8
https://stackoverflow.com/questions/52141857/how-to-make-return-char-function-in-c-programming/52141903
https://www.geeksforgeeks.org/merge-sort/
https://www.jianshu.com/p/cfe49c2c3194
https://www.runoob.com/cprogramming/c-sort-algorithm.html
http://c.biancheng.net/cpp/html/2741.html
https://www.runoob.com/w3cnote/quick-sort-2.html
https://blog.csdn.net/iluckyning/article/details/8141078
https://www.tutorialspoint.com/data_structures_algorithms/merge_sort_program_in_c.htm
http://c.biancheng.net/cpp/html/135.html
http://c.biancheng.net/cpp/html/137.html
https://www.google.com/search?q=%E5%BF%AB%E9%80%9F%E6%8E%92%E5%BA%8F&oq=%E5%BF%AB%E9%80%9F%E6%8E%92%E5%BA%8F&aqs=chrome..69i57j0i13i457j0i13j0i10i30l3j69i61l2.2032j0j9&sourceid=chrome&ie=UTF-8
https://stackoverflow.com/questions/11438794/is-the-size-of-c-int-2-bytes-or-4-bytes#:~:text=The%20size%20of%20an%20int,the%20program%20is%20executed%20on.
https://blog.csdn.net/lihuajie1003/article/details/51733644
http://webdocs.cs.ualberta.ca/~ghlin/CMPUT201/lab4303825694045563_06.html
http://c.biancheng.net/cpp/html/76.html
https://blog.csdn.net/stoneliul/article/details/8107587?utm_medium=distribute.pc_relevant.none-task-blog-title-1&spm=1001.2101.3001.4242
http://c.biancheng.net/cpp/html/2443.html
https://www.cnblogs.com/zpcdbky/p/4104694.html
