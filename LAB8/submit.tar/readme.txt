Wentai Du

Dicuss with: Jinlong Zhao,Ziying Li,Bowen Xiao

Books: 
Our Textbook
c programming language from entry to master 4th


LINK:
https://stackoverflow.com/questions/15458393/implicit-declaration-of-function-time-wimplicit-function-declaration
https://stackoverflow.com/questions/16856647/sqlite3-programmingerror-incorrect-number-of-bindings-supplied-the-current-sta
http://c.biancheng.net/view/223.html
http://c.biancheng.net/cpp/html/164.html
https://baike.baidu.com/item/fflush#:~:text=fflush%E6%98%AF%E4%B8%80%E4%B8%AA%E5%9C%A8C,stream%20%E6%8C%87%E5%AE%9A%E7%9A%84%E6%96%87%E4%BB%B6%E4%B8%AD%E3%80%82
http://c.biancheng.net/cpp/html/157.html
http://c.biancheng.net/view/235.html
https://bbs.csdn.net/topics/340063221?page=2
http://c.biancheng.net/cpp/html/263.html
https://www.coder.work/article/2215572
https://www.cnblogs.com/youxin/p/3234559.html
https://www.jianshu.com/p/03c3f6164eb2
https://www.google.com/search?q=fgets+eof&oq=fgets+EOF&aqs=chrome.0.0i457j0j0i22i30l6.13562j0j7&sourceid=chrome&ie=UTF-8
https://www.tutorialspoint.com/c_standard_library/c_function_getchar.htm
https://blog.csdn.net/da_kao_la/article/details/81036035
https://www.cnblogs.com/wxl845235800/p/7240291.html
https://www.runoob.com/cprogramming/c-examples-read-file.html
https://stackoverflow.com/questions/1345670/stack-smashing-detected
http://c.biancheng.net/cpp/html/170.html
http://c.biancheng.net/view/235.html
https://stackoverflow.com/questions/9712413/c-stack-smashing-detected/9712815
http://c.biancheng.net/cpp/html/2859.html
https://www.geeksforgeeks.org/core-dump-segmentation-fault-c-cpp/
https://blog.csdn.net/ArchyLi/article/details/52829725
https://blog.csdn.net/Mary19920410/article/details/71518130
https://zhidao.baidu.com/question/562976125076199884.html
https://blog.csdn.net/wucz122140729/article/details/105752178
https://docs.teradata.com/reader/~_sY_PYVxZzTnqKq45UXkQ/1T4XGYLp1M5ST7SemuydPg
https://blog.csdn.net/dream_1996/article/details/54884703
http://c.biancheng.net/view/2038.html
https://www.cnblogs.com/dolphin0520/archive/2011/10/02/2198280.html
https://www.cnblogs.com/lemaden/p/10427943.html
https://www.thinbug.com/q/20128638
https://stackoverflow.com/questions/12666146/can-uint8-t-be-a-non-character-type
https://blog.csdn.net/Mary19920410/article/details/71518130
https://zhidao.baidu.com/question/540122950.html
