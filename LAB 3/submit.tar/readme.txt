discuss with: Xibei Xie and Jinlong Zhao


part1:
Book: c programming language from entry to master 4th

part2 &part3:
Book: c programming language from entry to master 4th
https://blog.csdn.net/jiqiyu/article/details/61928786
https://www.runoob.com/cprogramming/c-pointer-to-an-array.html
https://blog.csdn.net/u011041241/article/details/51148145
https://www.tutorialspoint.com/c_standard_library/c_function_time.htm
https://blog.csdn.net/chunlovenan/article/details/44592603
https://www.runoob.com/w3cnote/c-time-func-summary.html 
https://zhidao.baidu.com/question/17556866.html?qbl=relate_question_2