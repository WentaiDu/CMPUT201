#include <stdio.h>
int main()
{
	int number_one,number_two;					//define integer
	number_one=10,number_two=5;					//assign vlaues to integer variables
	printf("The total is %d\n",(number_one+10-number_two)/5);	//print the result
	return 0;							//End program
}

